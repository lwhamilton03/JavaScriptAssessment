data = {
  "squadName" : "QA Consulting",
  "secretBase" : "Anchorage",
  "active" : true,
  "members" : [
    {
      "name" : "Matt",
      "age" : 29,
      "secretIdentity" : "The flash-er",
      "skills" : [
        "Java",
        "Testing",
        "JavaScript"
      ]
    },
    {
      "name" : "Dev",
      "age" : 32,
      "secretIdentity" : "Dev Data",
      "skills" : [
        "DevOps",
        "Linux",
        "Consultancy Skills"
      ]
    },
    {
      "name" : "Shafeeq",
      "age" : 32,
      "secretIdentity" : "T H E S H A F E E Q",
      "skills" : [
        "Databases",
        "Java",
        "JavaScript",
        "Chicken Cottage",
      ]
    }
  ]
}